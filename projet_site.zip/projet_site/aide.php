<?php include('includes/bdd.php')?>
<html>
    <?php $namePage = 'Annonce'; include('includes/head.php'); ?>
    <?php include('log.php'); ?>
    <body>
    <?php include('includes/header.php'); ?>
    <?php include('includes/message.php');?>
        <main>
          <div class="container-fluid" id="container-aide">
            <h1>Vous avez une question ? </h1>
            <div class="container-fluid" id="container-gestion">
              <div class="container-fluid" id="container-gestion4">
            <p>Vous pouvez nous contacter à l'adresse email suivante:  22matteoz@gmail.com</p>
            <p>Nous essaierons de vous répondre le plus vite possible</p>
          </div>
        </div>
      </div>
        </main>
        <div class="spacer50" id="spacer50"></div>
          <?php include('includes/footer.php'); ?>

    </body>s
</html>
