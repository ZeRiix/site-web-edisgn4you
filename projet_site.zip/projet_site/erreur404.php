<?php
include('includes/bdd.php');
?>
<html>
<?php
include('includes/head.php');
include('includes/header.php');
include('includes/message.php');
?>
<a href="deconnexion.php">retour acceuil</a>
<?php
include('includes/footer.php');
?>
</html>