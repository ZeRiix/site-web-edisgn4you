function retourAccueil(){
    window.location.href="index.php";
}
function validerAnnonce(){
    window.location.href="#"; // en attente d'une page php verif annonce et retour a l'index.
}