<?php include('includes/bdd.php')?>
<html>
    <?php $namePage = 'Annonce'; include('includes/head.php'); ?>
    <?php include('log.php'); ?>
    <body>
    <?php include('includes/header.php'); ?>
    <?php include('includes/message.php');?>
        <main>
          <div class="spacer50" id="spacer50x"></div>
          <div class="container-fluid" id="container-mentions">
            <h2>Présentation de E4you Pro</h2>
            <div class="container-fluid" id="container-e4u">
              <div class="spacer20" id="spacer20"></div>
              <h1>E4you Pro est un espace dédié aux professionnels permettant de mettre des offres en ligne sur notre site.
                Votre inscription vers l'espace Pro vous offrira de nouvelles opportunités dans le monde du e-design.
    </div>
  </div>
          </main>
            <div class="spacer50" id="spacer50x"></div>
            <?php include('includes/footer.php'); ?>

      </body>
  </html>
