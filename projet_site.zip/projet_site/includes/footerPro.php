<footer>
    <div class="container-fluid" id="container-2">
        <div class="row">
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">Catégories</p>
                <a id="categorie-footer" href="visionAnnonces.php?category=logo">Logo</a><br>
                <a id="categorie-footer" href="visionAnnonces.php?category=site">Site Web</a><br>
                <a id="categorie-footer" href="visionAnnonces.php?category=application">Application</a><br>
                <a id="categorie-footer" href="visionAnnonces.php?category=montage">Montages vidéos</a>
            </div>
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">A propos du site</p></a>
                <a href="mentionlegalesPro.php"><p id="categorie-footer">Mentions légales</p></a>
                <a href="aproposPro.php"><p id="categorie-footer">A propos de nous</p></a>
            </div>
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">Aide</p>
                <a href="aidePro.php"><p id="categorie-footer">Contactez-nous</p></a>
            </div>
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">Communauté</p>
                <a href="https://twitter.com/e4you4"><p id="categorie-footer"><img src="images/picto_twitter.png">  Twitter</p></a>
                <a href="https://www.instagram.com/e_designn4you/"><p id="categorie-footer"><img src="images/picto_insta.png">  Instagram</p></a>
                <p id="categorie-footer">Actualités</p>
            </div>
        </div>
        <!-- <?php echo 'Corporight ' . date('Y') . ' E-design4you By ZeRiix.';?> -->
    </div>
</footer>