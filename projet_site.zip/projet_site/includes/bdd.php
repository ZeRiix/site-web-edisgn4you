<?php

session_start();
// config MAMP SERVER
$bdd = new PDO('mysql:host=localhost;dbname=espace_membre', 'root', 'root');

?>