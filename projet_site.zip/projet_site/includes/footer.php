<footer>
    <div class="container-fluid" id="container-2">
        <div class="row">
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">Catégories</p>
                <a href="visionOffres.php?category=logo"><p id="categorie-footer">Logo</p></a>
                <a href="visionOffres.php?category=site"><p id="categorie-footer">Site Web</p></a>
                <a href="visionOffres.php?category=application"><p id="categorie-footer">Application</p></a>
                <a href="visionOffres.php?category=montage"><p id="categorie-footer">Montages vidéos</p></a>
            </div>
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">A propos du site</p></a>
                <a href="mentionlegales.php"><p id="categorie-footer">Mentions légales</p></a>
                <a href="apropos.php"><p id="categorie-footer">A propos de nous</p></a>
            </div>
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">Aide</p>
                <a href="aide.php"><p id="categorie-footer">Contactez-nous</p></a>
            </div>
            <div class="col-lg-3" id="footer">
                <p id="title-categorie-footer">Communauté</p>
                <a href="https://twitter.com/e4you4"><p id="categorie-footer"><img src="images/picto_twitter.png">  Twitter</p></a>
                <a href="https://www.instagram.com/e_designn4you/"><p id="categorie-footer"><img src="images/picto_insta.png">  Instagram</p></a>
            </div>
        </div>
        <!-- <?php echo 'Corporight ' . date('Y') . ' E-design4you By ZeRiix.';?> -->
    </div>
</footer>
