<header>
    <div class="container-fluid" style="border: solid 1px black; height: 90px">
        <div class="row">
            <div class="col-lg-4">
                <a href="page_admin.php"><img src="../images/fleche.png" height="65%"></a>
            </div>
            <div class="col-lg-4">
                <div align="center" class="logoAdmin">
                    <img src="../images/logo.png" width="30%" height="30%">
                </div>
            </div>
            <div class="col-lg-4">
                <!-- -->
            </div>
        </div>
    </div>
</header>