<!-- <?php // echo 'Corpyright ' . date('Y') . '©FLORENTIN William';?> -->
<footer id="footer">
    <div class="spacer20" style="height: 20px;"></div>
    <p style="text-align: center; color: black;"><?php echo 'Copyright ' . date('Y') . '©FLORENTIN William & SOLARI Mattéo';?></p>
</footer>